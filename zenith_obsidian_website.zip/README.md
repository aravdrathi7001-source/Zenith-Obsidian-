# Zenith Obsidian — Official Team Website

The official website for team **Zenith Obsidian** (MakeX Competitive Robotics).

## 🚀 Setup & Deployment

### Run Locally
Open `index.html` in any web browser.

### Deploy to GitHub Pages
1. Push this repository to GitHub.
2. Go to **Settings** > **Pages**.
3. Under **Branch**, select `main` and `/ (root)`.
4. Click **Save**.
